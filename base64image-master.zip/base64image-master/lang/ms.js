/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","ms",{
	"alt":"Text Alternatif",
	"lockRatio":"Tetapkan Nisbah",
	"vSpace":"Ruang Menegak",
	"hSpace":"Ruang Melintang",
	"border":"Border"
});